package codes;
// Sub Class
public class PersonalInfo2 extends Hobbies2{
	// A Sub class that inherits the properties of the Hobbies2 (Parent class)
	String Name = "Name: Kathlyn Jane B. Nabata";
	String age = "Age: 19";
	String location = "Location: Pasay City";
	String Sex = "Sex: Female";
	String MaritalStatus = "Maritial Status: Single";
	String Nationality = "Nationality: Filipino";
	String Religion = "Religion: Catholic";
}
