package codes;
// Sub class 1
public class EducAttain2 extends PersonalInfo2{
	// A sub class that inherits the properties the of PersonalInfo2(sub Class)
	String NU = "National Univeristy - Manila";
	String PCU = "Philippine Christian Univeristy";
	String AUJAS = "Arellano Univerity-JAS";
	String Elem = "Baclaran Elementary School UNIT 1";
	String NUYear = "(Current)";
	String PCUYear = "(2020-2022)";
	String AUJASYear = "(2016-2022)";
	String ELEMYear = "(2010-2016)";
	
}
