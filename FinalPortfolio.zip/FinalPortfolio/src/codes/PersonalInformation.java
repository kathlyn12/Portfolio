package codes;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PersonalInformation extends JFrame{
	
	EducAttain2 info = new EducAttain2();
	// Instantiation of the sub Class that inherited all value from parent class to subclasses
	// and created an object called info
	

	 JFrame InfoFrame;

	/**
	 * Launch the application.
	 */  
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PersonalInformation window = new PersonalInformation();
					window.InfoFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PersonalInformation() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		InfoFrame = new JFrame();
		InfoFrame.setBounds(100, 100, 757, 565); // frame size
		InfoFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		InfoFrame.setResizable(false);
		InfoFrame.setLocationRelativeTo(null); // center frame
		InfoFrame.getContentPane().setLayout(null);
		
		JLabel BackOption = new JLabel("BACK");
		BackOption.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) { // Mouse clicked
				MenuPage menu = new MenuPage();
				menu.MenuFrame.setVisible(true);
				InfoFrame.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) { // When hovering the mouse, the Label "BackOption" will change its color to white.
				BackOption.setForeground(Color.white);
			}
			@Override
			public void mouseExited(MouseEvent e) { // When hovering the mouse, the Label "BackOption" will change its color to black.
				BackOption.setForeground(Color.black);
			}
		});
		BackOption.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 25));
		BackOption.setBounds(160, 460, 71, 24);
		InfoFrame.getContentPane().add(BackOption);
		
		// using the object "info" we called the Name that is inherited from PersonalInfo2 (Parent Class)
		JLabel NameLabel = new JLabel(info.Name);
		NameLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 18)); 
		NameLabel.setBounds(415, 141, 271, 29);
		InfoFrame.getContentPane().add(NameLabel);
		
		// using the object "info" we called the age that is inherited from PersonalInfo2 (Parent Class)
		JLabel ageLabel = new JLabel(info.age);
		ageLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 18));
		ageLabel.setBounds(415, 180, 106, 24);
		InfoFrame.getContentPane().add(ageLabel);
		
		// using the object "info" we called the Location that is inherited from PersonalInfo2 (Parent Class)
		JLabel LocationLabel = new JLabel(info.location);
		LocationLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 18));
		LocationLabel.setBounds(415, 214, 180, 24);
		InfoFrame.getContentPane().add(LocationLabel);
		
		// using the object "info" we called the Sex that is inherited from PersonalInfo2 (Parent Class)
		JLabel SexLabel = new JLabel(info.Sex);
		SexLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 18));
		SexLabel.setBounds(415, 248, 117, 24);
		InfoFrame.getContentPane().add(SexLabel);
		
		// using the object "info" we called the Martial Status that is inherited from PersonalInfo2 (Parent Class)
		JLabel MaritialSLabel = new JLabel(info.MaritalStatus);
		MaritialSLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 18));
		MaritialSLabel.setBounds(415, 282, 226, 40);
		InfoFrame.getContentPane().add(MaritialSLabel);
		
		// using the object "info" we called the Nationality that is inherited from PersonalInfo2 (Parent Class)
		JLabel NationalityLabel = new JLabel(info.Nationality);
		NationalityLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 18));
		NationalityLabel.setBounds(415, 332, 186, 24);
		InfoFrame.getContentPane().add(NationalityLabel);
		
		// using the object "info" we called the Religion that is inherited from PersonalInfo2 (Parent Class)
		JLabel ReligionLabel = new JLabel(info.Religion);
		ReligionLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 18));
		ReligionLabel.setBounds(415, 375, 180, 29);
		InfoFrame.getContentPane().add(ReligionLabel);
		
		JLabel PersonalInfoImage = new JLabel(""); // Image icon
		PersonalInfoImage.setIcon(new ImageIcon(PersonalInformation.class.getResource("/images/Personal Information 2.png")));
		PersonalInfoImage.setBounds(0, -11, 743, 558);
		InfoFrame.getContentPane().add(PersonalInfoImage);
		
	}
}
