package codes;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Achievement {

	// Achievement Frame
	 JFrame AFrame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Achievement window = new Achievement();
					window.AFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Achievement() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		AFrame = new JFrame();
		AFrame.setBounds(100, 100, 756, 572); // frame size
		AFrame.setResizable(false);
		AFrame.setLocationRelativeTo(null); // center frame
		AFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		AFrame.getContentPane().setLayout(null);
		
		JLabel NextLabel = new JLabel("NEXT");
		NextLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) { // Mouse clicked
				Achievements2 A2 = new Achievements2();
				A2.Achieve2Frame.setVisible(true);
				AFrame.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) { // When hovering the mouse, the Label "NextLabel" will change its color to white.
				NextLabel.setForeground(Color.white);
			}
			@Override
			public void mouseExited(MouseEvent e) { // When hovering the mouse, the Label "NextLabel" will change its color to white.
				NextLabel.setForeground(Color.black);
			}
		});
		NextLabel.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 25));
		NextLabel.setBounds(157, 456, 72, 23);
		AFrame.getContentPane().add(NextLabel);
		
		JLabel AchievementsImage = new JLabel(""); //  Achievements Image Icon
		AchievementsImage.setIcon(new ImageIcon(Achievement.class.getResource("/images/Achievements (3).png")));
		AchievementsImage.setBounds(0, 0, 742, 535);
		AFrame.getContentPane().add(AchievementsImage);
	}

}
