package codes;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MainPage {

	// Main page
	private JFrame MainFrame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainPage window = new MainPage();
					window.MainFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainPage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		MainFrame = new JFrame();
		MainFrame.setBounds(100, 100, 758, 575); // Frame size
		MainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		MainFrame.setResizable(false); 
		MainFrame.setLocationRelativeTo(null); // Center form in the screen
		MainFrame.getContentPane().setLayout(null);
		
		JLabel StartLabel = new JLabel("START"); // Label Start
		StartLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) { // StartLabel mouse clicked.
				MenuPage menu = new MenuPage();  // instantiation 
				menu.MenuFrame.setVisible(true); 
				MainFrame.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) { // when hovering the mouse, the Label "Start" will change its color to white
				StartLabel.setForeground(Color.WHITE);
			}
			@Override
			public void mouseExited(MouseEvent e) { // when hovering the mouse, the Label "Start" will change its color to white
				StartLabel.setForeground(Color.BLACK);
			}
		});
		StartLabel.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 30));
		StartLabel.setBounds(328, 435, 100, 39);
		MainFrame.getContentPane().add(StartLabel); 
		
		JLabel MainPageImage = new JLabel(""); // Image Icon
		MainPageImage.setIcon(new ImageIcon(MainPage.class.getResource("/images/Main Page.png")));
		MainPageImage.setBounds(0, 0, 744, 538);
		MainFrame.getContentPane().add(MainPageImage); 
	}

}
