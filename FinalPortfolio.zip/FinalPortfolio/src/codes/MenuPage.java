package codes;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MenuPage {

	// Menu Frame
	JFrame MenuFrame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuPage window = new MenuPage();
					window.MenuFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MenuPage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		MenuFrame = new JFrame();
		MenuFrame.setBounds(100, 100, 756, 572); // Frame size
		MenuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		MenuFrame.setResizable(false);
		MenuFrame.setLocationRelativeTo(null); // center form in the screen
		MenuFrame.getContentPane().setLayout(null);
		
		JLabel PersonalInfo = new JLabel("Personal Information"); // Personal Info label
		PersonalInfo.setForeground(new Color(0, 0, 0));
		PersonalInfo.addMouseListener(new MouseAdapter() { // MouseListener
			@Override
			public void mouseClicked(MouseEvent e) { // MouseListener
				PersonalInformation info = new PersonalInformation(); 
				info.InfoFrame.setVisible(true); 
				MenuFrame.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) { // When hovering the mouse, the Label "PerosnalInfo" will change its color to white.
				PersonalInfo.setForeground(Color.WHITE);
			}
			@Override
			public void mouseExited(MouseEvent e) { // When hovering the mouse, the Label "PersonalInfo" will change its color to black.
				PersonalInfo.setForeground(Color.black);
			}
		});
		PersonalInfo.setFont(new Font("Trebuchet MS", Font.BOLD, 17));
		PersonalInfo.setBounds(137, 89, 174, 51);
		MenuFrame.getContentPane().add(PersonalInfo); 
		
		JLabel Hobbies = new JLabel("Hobbies"); // Hobbies Label
		Hobbies.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) { // Mouse clicked
				Hobbies hobby = new Hobbies(); 
				hobby.HobbyFrame.setVisible(true); 
				MenuFrame.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) { // When hovering the mouse, the Label "Hobbies" will change its color to white.
				Hobbies.setForeground(Color.WHITE);
			}
			@Override
			public void mouseExited(MouseEvent e) { // When hovering the mouse, the Label "Hobbies" will change its color to black.
				Hobbies.setForeground(Color.BLACK);
			}
		});
		Hobbies.setForeground(new Color(0, 0, 0));
		Hobbies.setFont(new Font("Trebuchet MS", Font.BOLD, 18));
		Hobbies.setBounds(490, 103, 73, 21);
		MenuFrame.getContentPane().add(Hobbies);
		
		JLabel SW = new JLabel("Strength and Weaknesses"); // Strength and Weaknesses Label
		SW.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) { // Mouse Clicked
				StrengthAndWeaknesses SW = new StrengthAndWeaknesses(); // Instantiation
				SW.SWFrame.setVisible(true); 
				MenuFrame.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) { // When hovering the mouse, the Label "SW" will change its color to white.
				SW.setForeground(Color.white);
			}
			@Override
			public void mouseExited(MouseEvent e) { // When hovering the mouse, the Label "SW" will change its color to black.
				SW.setForeground(Color.black);
			}
		});
		SW.setForeground(new Color(0, 0, 0));
		SW.setFont(new Font("Trebuchet MS", Font.BOLD, 17));
		SW.setBounds(117, 237, 208, 44);
		MenuFrame.getContentPane().add(SW);
		
		JLabel EducAttain = new JLabel("Educational Attainment"); // EductAttain Label
		EducAttain.addMouseListener(new MouseAdapter() { 
			@Override
			public void mouseClicked(MouseEvent e) { // Mouse clicked
				EducationalAttainment educ = new EducationalAttainment(); // Instantiation 
				educ.EducFrame.setVisible(true); 
				MenuFrame.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) { // When hovering the mouse, the Label "EducAttain" will change its color to white.
				EducAttain.setForeground(Color.white);
			}
			@Override
			public void mouseExited(MouseEvent e) { // When hovering the mouse, the Label "EducAttain" will change its color to black.
				EducAttain.setForeground(Color.black);
			}
		});
		EducAttain.setForeground(new Color(0, 0, 0));
		EducAttain.setFont(new Font("Trebuchet MS", Font.BOLD, 17));
		EducAttain.setBounds(427, 240, 194, 38);
		MenuFrame.getContentPane().add(EducAttain);
		
		JLabel Achieve = new JLabel("Achievements"); // Achievements Label
		Achieve.addMouseListener(new MouseAdapter() { 
			@Override
			public void mouseClicked(MouseEvent e) { // Mouse clicked
				Achievement achieve = new Achievement(); // Instantiation 
				achieve.AFrame.setVisible(true); 
				MenuFrame.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) { // When hovering the mouse, the Label "Achieve" will change its color to white.
				Achieve.setForeground(Color.white);
			}
			@Override
			public void mouseExited(MouseEvent e) { // When hovering the mouse, the Label "Achieve" will change its color to black.
				Achieve.setForeground(Color.black);
			}
		});
		Achieve.setForeground(new Color(0, 0, 0));
		Achieve.setFont(new Font("Trebuchet MS", Font.BOLD, 18));
		Achieve.setBounds(160, 387, 122, 38);
		MenuFrame.getContentPane().add(Achieve);
		
		JLabel skill = new JLabel("Skills"); // Skills label
		skill.addMouseListener(new MouseAdapter() { // Mouse Listener
			@Override
			public void mouseClicked(MouseEvent e) {
				Skills skills = new Skills(); // instantiation 
				skills.SkillFrame.setVisible(true); 
				MenuFrame.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) { // When hovering the mouse, the Label "skill" will change its color to white.
				skill.setForeground(Color.white);
			}
			@Override
			public void mouseExited(MouseEvent e) { // When hovering the mouse, the Label "skill" will change its color to black.
				skill.setForeground(Color.black);
			}
		});
		skill.setForeground(new Color(0, 0, 0));
		skill.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		skill.setBounds(493, 392, 99, 29);
		MenuFrame.getContentPane().add(skill);
		
		JLabel MenuPageImage = new JLabel(""); // Image Icon
		MenuPageImage.setIcon(new ImageIcon(MenuPage.class.getResource("/images/Menu Page.png")));
		MenuPageImage.setBounds(0, 0, 748, 535);
		MenuFrame.getContentPane().add(MenuPageImage);
	}
}
