package codes;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Achievements2 {

	// Second part of the Achievements Frame
	 JFrame Achieve2Frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Achievements2 window = new Achievements2();
					window.Achieve2Frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Achievements2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		Achieve2Frame = new JFrame();
		Achieve2Frame.setBounds(100, 100, 757, 576); // frame size
		Achieve2Frame.setResizable(false);
		Achieve2Frame.setLocationRelativeTo(null); // center frame
		Achieve2Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Achieve2Frame.getContentPane().setLayout(null);
		
		JLabel BackLabel = new JLabel("BACK");
		BackLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) { // Mouse clicked
				MenuPage menu = new MenuPage();
				menu.MenuFrame.setVisible(true);
				Achieve2Frame.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) { // When hovering the mouse, the Label "BackLabel" will change its color to white.
				BackLabel.setForeground(Color.white);
			}
			@Override
			public void mouseExited(MouseEvent e) { // When hovering the mouse, the Label "BackLabel" will change its color to black.
				BackLabel.setForeground(Color.black);
			}
		});
		BackLabel.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 25));
		BackLabel.setBounds(160, 459, 74, 30);
		Achieve2Frame.getContentPane().add(BackLabel);
		
		JLabel AImage2 = new JLabel(""); // Image icon
		AImage2.setIcon(new ImageIcon(Achievements2.class.getResource("/images/Achievements2.png")));
		AImage2.setBounds(0, 0, 743, 539);
		Achieve2Frame.getContentPane().add(AImage2);
	}

}
