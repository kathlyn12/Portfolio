package codes;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Hobbies extends JFrame {

	 JFrame HobbyFrame; // Hobby Frame

		EducAttain2 hobbies = new EducAttain2();
		// Instantiation of the sub Class that inherited all value from parent class to subclasses
		// and created an object called hobbies

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Hobbies window = new Hobbies();
					window.HobbyFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Hobbies() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		HobbyFrame = new JFrame(); // Hobby Frame
		HobbyFrame.setBounds(100, 100, 758, 575);
		HobbyFrame.setResizable(false);
		HobbyFrame.setLocationRelativeTo(null); // center frame
		HobbyFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		HobbyFrame.getContentPane().setLayout(null);
		
		JLabel BackOption = new JLabel("BACK");
		BackOption.addMouseListener(new MouseAdapter() { // mouse listener
			@Override
			public void mouseClicked(MouseEvent e) {
				MenuPage menu = new MenuPage();
				menu.MenuFrame.setVisible(true);
				HobbyFrame.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) { // When hovering the mouse, the Label "BackLabel" will change its color to white.
				BackOption.setForeground(Color.WHITE);
			}
			@Override
			public void mouseExited(MouseEvent e) { // When hovering the mouse, the Label "BackLabel" will change its color to black.
				BackOption.setForeground(Color.BLACK);
			}
		});
		BackOption.setForeground(new Color(0, 0, 0));
		BackOption.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 25));
		BackOption.setBounds(162, 459, 61, 29);
		HobbyFrame.getContentPane().add(BackOption);
		
		// using the object "hobbies" we called the hobby1 that is inherited from Hobbies2 (Sub Class)
		JLabel Hobby1Label = new JLabel(hobbies.hobby1);
		Hobby1Label.setFont(new Font("Verdana", Font.BOLD, 25));
		Hobby1Label.setBounds(415, 170, 274, 29);
		HobbyFrame.getContentPane().add(Hobby1Label);
		
		// using the object "hobbies" we called the hobby2 that is inherited from Hobbies2 (Sub Class)
		JLabel Hobby2Label = new JLabel(hobbies.hobby2);
		Hobby2Label.setFont(new Font("Verdana", Font.BOLD, 25));
		Hobby2Label.setBounds(415, 221, 257, 29);
		HobbyFrame.getContentPane().add(Hobby2Label);
		
		// using the object "hobbies" we called the hobby3 that is inherited from Hobbies2 (Sub Class)
		JLabel Hobby3Label = new JLabel(hobbies.hobby3);
		Hobby3Label.setFont(new Font("Verdana", Font.BOLD, 25));
		Hobby3Label.setBounds(413, 265, 154, 29);
		HobbyFrame.getContentPane().add(Hobby3Label);
		
		// using the object "hobbies" we called the hobby4 that is inherited from Hobbies2 (Sub Class)
		JLabel Hobby4Label = new JLabel(hobbies.hobby4);
		Hobby4Label.setFont(new Font("Verdana", Font.BOLD, 23));
		Hobby4Label.setBounds(415, 310, 288, 29);
		HobbyFrame.getContentPane().add(Hobby4Label);
		
		// using the object "hobbies" we called the hobby5 that is inherited from Hobbies2 (Sub Class)
		JLabel Hobby5Label = new JLabel(hobbies.hobby5);
		Hobby5Label.setFont(new Font("Verdana", Font.BOLD, 25));
		Hobby5Label.setBounds(415, 355, 288, 29);
		HobbyFrame.getContentPane().add(Hobby5Label);
		
		JLabel HobbyImage = new JLabel(""); // hobby Image icon
		HobbyImage.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		HobbyImage.setIcon(new ImageIcon(Hobbies.class.getResource("/images/Hobbies2.png")));
		HobbyImage.setBounds(0, 0, 744, 538);
		HobbyFrame.getContentPane().add(HobbyImage);
		
		
	}
}
