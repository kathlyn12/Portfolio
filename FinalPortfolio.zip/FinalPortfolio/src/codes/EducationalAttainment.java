package codes;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;

public class EducationalAttainment extends JFrame {

	// Educ Frame
	 JFrame EducFrame;
	 
		EducAttain2 EAttain = new EducAttain2();
		// Instantiation of the sub Class that inherited all value from parent class to subclasses
		// and created an object called EAttain

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EducationalAttainment window = new EducationalAttainment();
					window.EducFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public EducationalAttainment() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		EducFrame = new JFrame();
		EducFrame.setBounds(100, 100, 756, 572); // Frame size
		EducFrame.setResizable(false);
		EducFrame.setLocationRelativeTo(null); // center frame
		EducFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		EducFrame.getContentPane().setLayout(null);
		
		JLabel BackLabel = new JLabel("BACK");
		BackLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) { // Mouse clicked
				MenuPage menu = new MenuPage();
				menu.MenuFrame.setVisible(true);
				EducFrame.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) { // When hovering the mouse, the Label "BackLabel" will change its color to white.
				BackLabel.setForeground(Color.white);
			}
			@Override
			public void mouseExited(MouseEvent e) { // When hovering the mouse, the Label "BackLabel" will change its color to Black.
				BackLabel.setForeground(Color.black);
			}
		});
		BackLabel.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 25));
		BackLabel.setBounds(159, 457, 85, 27);
		EducFrame.getContentPane().add(BackLabel);
		
		// using the object "EAttain" we called the NU that is inherited from EducAttain2 (Sub Class)
		JLabel EducLabel = new JLabel(EAttain.NU); 
		EducLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		EducLabel.setBounds(412, 122, 286, 34);
		EducFrame.getContentPane().add(EducLabel);
		
		// using the object "EAttain" we called the NUYear that is inherited from EducAttain2 (Sub Class)
		JLabel NUYearLabel = new JLabel(EAttain.NUYear); 
		NUYearLabel.setHorizontalAlignment(SwingConstants.CENTER);
		NUYearLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		NUYearLabel.setBounds(480, 145, 131, 34);
		EducFrame.getContentPane().add(NUYearLabel);
		
		// using the object "EAttain" we called the PCU that is inherited from EducAttain2 (Sub Class)
		JLabel PCULabel = new JLabel(EAttain.PCU); 
		PCULabel.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		PCULabel.setBounds(398, 189, 300, 34);
		EducFrame.getContentPane().add(PCULabel);
		
		// using the object "EAttain" we called the PCUYear that is inherited from EducAttain2 (Sub Class)
		JLabel PCUYearLabel = new JLabel(EAttain.PCUYear); 
		PCUYearLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		PCUYearLabel.setBounds(493, 217, 118, 27);
		EducFrame.getContentPane().add(PCUYearLabel);
		
		// using the object "EAttain" we called the AUJAS that is inherited from EducAttain2 (Sub Class)
		JLabel AUJASLabel = new JLabel(EAttain.AUJAS); 
		AUJASLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		AUJASLabel.setBounds(440, 264, 229, 34);
		EducFrame.getContentPane().add(AUJASLabel);
		
		// using the object "EAttain" we called the AUJASYear that is inherited from EducAttain2 (Sub Class)
		JLabel AUJASYearLabel = new JLabel(EAttain.AUJASYear); 
		AUJASYearLabel.setBounds(480, 288, 118, 27);
		AUJASYearLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		EducFrame.getContentPane().add(AUJASYearLabel);
		
		// using the object "EAttain" we called the Elem that is inherited from EducAttain2 (Sub Class)
		JLabel ELEMLabel = new JLabel(EAttain.Elem); 
		ELEMLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		ELEMLabel.setBounds(384, 335, 335, 27);
		EducFrame.getContentPane().add(ELEMLabel);
		
		//using the object "EAttain" we called the ELEMYear that is inherited from EducAttain2 (Sub Class)
		JLabel ELEMYearLabel = new JLabel(EAttain.ELEMYear); 
		ELEMYearLabel.setBounds(487, 359, 124, 25);
		ELEMYearLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		EducFrame.getContentPane().add(ELEMYearLabel);
		
		JLabel EducImage = new JLabel(""); // Image icon
		EducImage.setFont(new Font("Trebuchet MS", Font.BOLD, 18));
		EducImage.setIcon(new ImageIcon(EducationalAttainment.class.getResource("/images/Educational Attainment .png")));
		EducImage.setBounds(0, 0, 742, 535);
		EducFrame.getContentPane().add(EducImage);
		
		
	}
}
