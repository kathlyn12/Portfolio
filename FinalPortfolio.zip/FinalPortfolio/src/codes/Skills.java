package codes;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Skills {

	// Skills Frame
	JFrame SkillFrame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Skills window = new Skills();
					window.SkillFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Skills() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		SkillFrame = new JFrame();
		SkillFrame.setBounds(100, 100, 758, 575); // Frame Size
		SkillFrame.setResizable(false);
		SkillFrame.setLocationRelativeTo(null); // Center Frame
		SkillFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SkillFrame.getContentPane().setLayout(null);
		
		JLabel BackOption = new JLabel("BACK");
		BackOption.addMouseListener(new MouseAdapter() { // Mouse Listener
			@Override
			public void mouseClicked(MouseEvent e) { // When hovering the mouse, the Label "BackOption" will change its color to white.
				MenuPage menu = new MenuPage();
				menu.MenuFrame.setVisible(true);
				SkillFrame.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) { // When hovering the mouse, the Label "BackOption" will change its color to white.
				SkillFrame.setForeground(Color.white);
			}
			@Override
			public void mouseExited(MouseEvent e) { // When hovering the mouse, the Label "BackOption" will change its color to Black.
				SkillFrame.setForeground(Color.black);
			}
		});
		BackOption.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 25));
		BackOption.setBounds(161, 458, 74, 30);
		SkillFrame.getContentPane().add(BackOption);
		
		JLabel SkillImage = new JLabel(""); // Image icon
		SkillImage.setIcon(new ImageIcon(Skills.class.getResource("/images/Skills.png")));
		SkillImage.setBounds(0, 0, 744, 538);
		SkillFrame.getContentPane().add(SkillImage);
	}

}
