package codes;
// Parent Class
public class Hobbies2  {
	String hobby1 = "Reading Mahnwas";
	String hobby2 = "Watching Movies";
	String hobby3 = "Singing";
	String hobby4 = "Playing Online Games";
	String hobby5 = "Listening to Musics";
}
