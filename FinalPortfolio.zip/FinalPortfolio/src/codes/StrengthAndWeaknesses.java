package codes;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class StrengthAndWeaknesses {

	// Strength and Weaknesses Frame
	JFrame SWFrame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StrengthAndWeaknesses window = new StrengthAndWeaknesses();
					window.SWFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StrengthAndWeaknesses() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		SWFrame = new JFrame();
		SWFrame.setBounds(100, 100, 758, 575); // Frame size
		SWFrame.setResizable(false);
		SWFrame.setLocationRelativeTo(null); // center frame
		SWFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SWFrame.getContentPane().setLayout(null);
		
		JLabel BackOption = new JLabel("BACK");
		BackOption.addMouseListener(new MouseAdapter() { // Mouse Listener
			@Override
			public void mouseClicked(MouseEvent e) {
				MenuPage menu = new MenuPage();
				menu.MenuFrame.setVisible(true);
				SWFrame.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				BackOption.setForeground(Color.white);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				BackOption.setForeground(Color.black);
			}
		});
		BackOption.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 25));
		BackOption.setBounds(160, 459, 67, 30);
		SWFrame.getContentPane().add(BackOption);
		
		JLabel SWImage = new JLabel("");
		SWImage.setIcon(new ImageIcon(StrengthAndWeaknesses.class.getResource("/images/Strength and Weaknesses .png")));
		SWImage.setBounds(0, 0, 744, 538);
		SWFrame.getContentPane().add(SWImage);
	}

}
